/**************************************************************************
ZONESTAR 3D PRINTER DIY KIT Firmware Configuaration
http://www.zonestar3d.com/
**************************************************************************/
#ifndef __CONFIG_H__
#define __CONFIG_H__

#include "modellist.h"

/*********************************************************************************************************
//Choose one printer model from the model list
//about the model list, please see the "modellist.h" file
*********************************************************************************************************/
#define	MODEL_NUMBER		Z6BS
/*********************************************************************************************************/
//common setting for all of model
//Some of the settings may be covered behind
/*********************************************************************************************************/
#define MOTHERBOARD 				BOARD_ZMIB
#define	IS_ZMIB_V2
#define ZONESTAR_OLED12864
#define	USE_SOFTWARE_SPI			1

#define	STRING_CONFIG_H_AUTHOR		"(Hally@ZONESTAR)"
#define	EEPROM_VERSION				"V55"
#define CUSTOM_MACHINE_NAME 		"Z6S"
#define	STRING_FIRMWARE_VERSION		"Firmware Ver:V3.0"
#define	_FIRMWARE_RELEASE_DATE_		"2020-07-28"

#define	SHOW_ZONESTAR_LOGO
#define	INDIVIDUAL_AXIS_HOMING_MENU
#define	ADJUST_MIN_POS_MENU
#define	LCD_INFO_MENU
#define	PRINTCOUNTER
#define FAN_SOFT_PWM
#define	EXTRUDER_AUTO_FAN_SPEED		255
#define DISABLE_BEDLEVELING_SENSOR

#define	EXTRUDERS					1
#define	PTFE_TUBE_LENGTH			300
#define DEFAULT_Kp 					20
#define DEFAULT_Ki 					1.6
#define DEFAULT_Kd 					62

#define	X_STEPS_PERMM				80
#define	Y_STEPS_PERMM				80
#define	Z_STEPS_PERMM				400
#define	E_STEPS_PERMM				80
#define	MAX_ACC_X					2000
#define	MAX_ACC_Y					800
#define	MAX_ACC_Z					100

#define INVERT_X_DIR 				true
#define INVERT_Y_DIR 				false
#define INVERT_Z_DIR 				false
#define	BED_SIZE 					150
#define X_MIN_POS 					-23
#define Y_MIN_POS 					0
#define Z_MIN_POS 					0

/**
 * LCD LANGUAGE
 *
 * Select the language to display on the LCD. These languages are available:
 *
 *    en, an, bg, ca, cn, cz, cz_utf8, de, el, el-gr, es, eu, fi, fr, fr_utf8, gl,
 *    hr, it, kana, kana_utf8, nl, pl, pt, pt_utf8, pt-br, pt-br_utf8, ru, sk_utf8,
 *    tr, uk, zh_CN, zh_TW, test
 *
 * :{ 'en':'English', 'an':'Aragonese', 'bg':'Bulgarian', 'ca':'Catalan', 'cn':'Chinese', 'cz':'Czech', 
 	'cz_utf8':'Czech (UTF8)', 'de':'German', 'el':'Greek', 'el-gr':'Greek (Greece)', 'es':'Spanish', 'eu':'Basque-Euskera', 
 	'fi':'Finnish', 'fr':'French', 'fr_utf8':'French (UTF8)', 'gl':'Galician', 'hr':'Croatian', 'it':'Italian', 
 	'kana':'Japanese', 'kana_utf8':'Japanese (UTF8)', 'nl':'Dutch', 'pl':'Polish', 'pt':'Portuguese', 'pt-br':'Portuguese (Brazilian)', 
 	'pt-br_utf8':'Portuguese (Brazilian UTF8)', 'pt_utf8':'Portuguese (UTF8)', 'ru':'Russian', 'sk_utf8':'Slovak (UTF8)', 'tr':'Turkish', 
 	'uk':'Ukrainian', 'zh_CN':'Chinese (Simplified)', 'zh_TW':'Chinese (Taiwan)', test':'TEST' }
 */
#define LCD_LANGUAGE es

/*********************************************************************************************************/
//END of common setting
/*********************************************************************************************************/

/*************************************************************************************************/
//Z6 Serial
/*************************************************************************************************/
#if(MODEL_NUMBER == Z6S)
//Z6 1st version, Single extruder, OLED128x64 and Knob keypad, ZMIB control board, without heatbed
#define	DISABLED_HEATBED


#elif(MODEL_NUMBER == Z6BS)
//Z6 2nd version, Single extruder, OLED128x64 and Knob keypad, ZMIBV2 control board

#endif
/*********************************************************************************************************
END of Setting for special model
*********************************************************************************************************/


//#define	XM_FAULT
//#define	YM_FAULT
//#define	ZM_FAULT
//#define E0M_FAULT

#endif // __CONFIG_H__
