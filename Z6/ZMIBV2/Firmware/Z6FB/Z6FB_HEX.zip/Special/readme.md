### Z6BS_XMFault
To fix the X motor drive fault issue, exchange X axis motor connector to E0 motor connector and exchange E0 motor connector to E0 motor connector.
### Z6BS_YMFault 
To fix the Y motor drive fault issue, exchange Y axis motor connector to E0 motor connector and exchange E0 motor connector to E0 motor connector.
### Z6BS_ZMFault
To fix the Z motor drive fault issue, exchange Z axis motor connector to E0 motor connector and exchange E0 motor connector to E0 motor connector.
### Z6BS_EMFault
To fix the E motor drive fault issue,exchange E0 motor connector to E0 motor connector.
