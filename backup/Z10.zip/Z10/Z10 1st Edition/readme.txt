Please make sure the LCD type before upload firmware, you can see the LCD type from LCD menu: About printer>>Board info>>
if you can see "ZONESTAR LCD12864" on the borad info list, please choose firmware in "ZONESTAR LCD" directory, otherwise please choose firmware in "Raprap LCD" directory.
