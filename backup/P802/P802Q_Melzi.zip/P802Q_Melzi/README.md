## Firmware
### :arrow_down: [P802Q: Melzi board, 5 button Control Panel](./P802Q_Melzi_Marlin_V12.zip)





