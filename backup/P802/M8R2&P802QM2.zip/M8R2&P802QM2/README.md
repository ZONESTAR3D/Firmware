## Firmware
### :arrow_down: [V3.3.0](./V3_3_0.zip)
### :arrow_down: [V3.4.0](./V3_4_0.zip)

## Wiring Diagram
![](./M8R2-ZRIBV6.jpg)
![](./M8S-ZRIBV6.jpg)
