1. Dual Z motor and Dual Z ENDSTOP
2. Control Board is ZRIBV6
3. LCD screen is Reprap LCD12864 (with SD socket)