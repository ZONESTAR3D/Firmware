Reprap LCD Screen:   With two LCD cable and there is a SD card socket on the LCD screen board.
ZONESTAR LCD screen: With one LCD cable and there ISNOT sd card socket on the LCD screen board