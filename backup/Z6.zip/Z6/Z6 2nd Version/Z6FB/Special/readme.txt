Z6BS_XMFault : exchange XM to E0M, and E0M to E1M
Z6BS_YMFault : exchange YM to E0M, and E0M to E1M
Z6BS_ZMFault : exchange ZM to E0M, and E0M to E1M
Z6BS_EMFault : exchange E0M to E1M
