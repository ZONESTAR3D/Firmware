### About how to upload firmware of the 3d printer, please refer to [:point_right: here](https://github.com/ZONESTAR3D/Firmware/tree/master/Z9/Z9V5/bin#how-to-upload-firmware-to-z9v5pro)

-----
## Release Note
### [:arrow_down: Z9V5Pro-MK6 V1.2](./Z9V5ProMK6_V1_2.zip)
- **Date:** 2023-08-12
- ***First release***





