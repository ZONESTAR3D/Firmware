Upload Steps:
1. Download the zip file and unzip it
2. Copy firmware.bin to the root directoy of Micro-SD card
3. Power off the printer and plug the Micro-SD card into sokect on control board
4. Power on the printer, wait about 30 seconds
5. Power off and power on the printer again